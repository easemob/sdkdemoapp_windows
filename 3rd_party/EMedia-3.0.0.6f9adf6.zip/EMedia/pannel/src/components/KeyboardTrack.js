var _util = require('../../../webrtc/src/components/Util');
var _logger = _util.tagLogger("Keyboard");


module.exports = _util.prototypeExtend({
    onKeyDown: function (btn) {
        
    },
    
    onKeyUp: function (btn) {
        
    }
});