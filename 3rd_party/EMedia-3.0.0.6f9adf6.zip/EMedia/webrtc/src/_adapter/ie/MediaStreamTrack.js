var _util = require('../../components/Util');
var _logger = _util.tagLogger("IE");

var MediaStreamTrack = _util.prototypeExtend({
    //plugin:
    //xplugin:

    //id
    //_xobj: xtrack,

    //contentHint
    //enabled
    //id
    //kind "audio|video"
    //label
    //muted
    //readonly
    //readyState
    //remote

    //stop()
    //onmute
    //onunmute
    //onended

    __init__: function () {
        this.kind();
        this.state();
        this.remote();
        this.label();
        this.enable();
    },

    kind: function () {
        var self = this;
        return self.kind = self.xplugin.GetTrackKind(self._xobj.id);
    },
    state: function () {
        var self = this;
        return self.state = self.xplugin.GetTrackState(self._xobj.id);
    },
    remote: function () {
        var self = this;
        return self.remote = self.xplugin.GetTrackRemote(self._xobj.id);
    },
    label: function () {
        var self = this;
        return self.label = self.xplugin.GetTrackLabel(self._xobj.id);
    },
    enable: function (enabled) {
        var self = this;

        if(enabled === undefined){
            return self.enabled = self.xplugin.GetTrackEnable(self._xobj.id);
        }

        var result = self.xplugin.SetTrackEnable(self._xobj.id, !!enabled);
        if(result){
            self.enabled = enabled;
        }
    },
    stop: function () {
        var self = this;
        self.xplugin.StopCapture(self._xobj.id);
    }
});

module.exports = MediaStreamTrack;