var _util = require('../../components/Util');
var _logger = _util.tagLogger("IE");

var MediaDevicesInfo = _util.prototypeExtend({
    //deviceId
    //groupId
    //kind
    //label
});

module.exports = MediaDevicesInfo;