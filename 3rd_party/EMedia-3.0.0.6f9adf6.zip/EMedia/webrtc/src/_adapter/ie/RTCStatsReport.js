var _util = require('../../components/Util');
var _logger = _util.tagLogger("IE");

var RTCStatsReport = _util.prototypeExtend({

});

module.exports = RTCStatsReport;