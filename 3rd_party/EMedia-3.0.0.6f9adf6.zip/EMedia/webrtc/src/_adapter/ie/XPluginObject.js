var _util = require('../../components/Util');

var cls = {};
var RTCError = cls.RTCError = require("./RTCError");
var RTCSessionDescription = cls.RTCSessionDescription = require('./RTCSessionDescription');
var RTCIceCandidate = cls.RTCIceCandidate = require('./RTCIceCandidate');
var MediaStream = cls.MediaStream = require('./MediaStream');
var MediaStreamTrack = cls.MediaStreamTrack = require('./MediaStreamTrack');
var RTCStatsReport = cls.RTCStatsReport = require('./RTCStatsReport');

var RTCPeerConnection = require('./RTCPeerConnection');
var MediaDevices = require('./MediaDevices');

var XVideo = require('./XVideoObject');


var _logger = _util.tagLogger("IE.plugin");

var hasMatch = /\brv[ :]+(\d+)/g.exec(navigator.userAgent) || [];
var webrtcDetectedVersion   = parseInt(hasMatch[1], 10);

var globalPluginSeqno = 0;
var plugins = emedia.__ieWebrtcPlugins__ = (emedia.__ieWebrtcPlugins__ || {});

var State = {
    NONE : 0,           // no plugin use
    INITIALIZING : 1,   // Detected need for plugin
    INJECTING : 2,      // Injecting plugin
    INJECTED: 3,        // Plugin element injected but not usable yet
    READY: 4
};

var Plugin = _util.prototypeExtend({
    id: _util.list("plugin", globalPluginSeqno++).join("_"),
    classid: 'clsid:8b9cc1b7-2703-44bc-a317-a025b24b7464',
    width: 0,
    height: 0,

    cbScrpitTags: [],
    pcs: {},

    // params: {},
    param: function (name, value) {
        (this.params || (this.params = {}))[name] = value;
        return this;
    },

    release: function () {
        removePlugin(this);
    }
});

function paramsHTMLTag(params) {
    var html = "";
    _util.forEach(params, function (param, value) {
        html += _util.list("<param name='", param, "'", "value='", value, "'", "/>").join(" ");
    });

    return html;
}

function inject(plugin, injected) {
    _logger.info("plugin injecting...");

    // // only inject once the page is ready
    // if (document.readyState !== 'interactive' && document.readyState !== 'complete') {
    //     _logger.warn("plugin inject fail. document.readyState", document.readyState);
    //     return;
    // }

    var plugin = plugins[plugin.id];
    if(!plugin){
        _logger.error("require plugin.");
        throw "Require plugin."
    }

    if (plugin.state !== State.INJECTING) {
        _logger.error("plugin inject fail. not injecting. ", plugin.state);
        return;
    }

    if (webrtcDetectedVersion <= 10) {
        //"<object id=\"WebRtcPlugin\" classid=\"clsid:8b9cc1b7-2703-44bc-a317-a025b24b7464\" width=\"0\" height=\"0\"></object>"
        plugin.innerHTML = _util.list('<object id="', plugin.id, '"',
            'classid="', plugin.classid, '"',
            'width="', plugin.width, '"',
            'height="', plugin.height, '"', '/>').join(" ");

        plugin.tag = document.getElementById(plugin.id);

        if(plugin.params){
            var pluginObject = plugin.tag.getElementById("#" + plugin.id);
            pluginObject.innerHTML = paramsHTMLTag(plugin.params);
        }
    } else {
        plugin.tag = document.createElement('object');
        plugin.tag.id = plugin.id;
        plugin.tag.classid =plugin.classid;
        plugin.tag.width = '0px';
        plugin.tag.height = '0px';

        if(plugin.params){
            var pluginObject = plugin.tag.getElementById("#" + plugin.id);
            plugin.tag.innerHTML = paramsHTMLTag(plugin.params);
        }
    }

    document.body.appendChild(plugin._xobj = plugin.tag);

    plugin.state = State.INJECTED;
    _logger.warn("plugin injected");

    injected && setTimeout(injected.bind(this), 50);

    return plugin;
}

function setXObjCallback(plugin, callback, eventAttr){
    eventAttr = (eventAttr || callbackname);

    var callbackname = "__easemob_ie_webrtc_plugin_" + plugin.id + "$" + eventAttr;
    var callbackScrpit = document.getElementById("#" + callbackname);
    if(callbackScrpit){
        return;
    }

    callbackScrpit = document.createElement("script");
    callbackScrpit.language = "javascript";
    callbackScrpit.for = plugin.id;
    callbackScrpit.event = eventAttr + "()";
    callbackScrpit.innerHTML = callbackname + "()";

    window[callbackname] = callback.bind(plugin);

    plugin.cbScrpitTags.push(callbackScrpit);

    document.body.appendChild(callbackScrpit);
}

function removePlugin(plugin) {
    plugin.tag && document.removeChild(plugin.tag);
    plugin.tag === undefined;

    _util.forEach(plugin.cbScrpitTags, function (_index, cbTag) {
        cbTag && document.removeChild(cbTag);
    });
    plugin.cbScrpitTags = [];
}

function isPluginInstalled(clsid, installedCb, notInstalledCb) {
    try {
        var shellObj = new ActiveXObject("WScript.Shell");
        var progid = shellObj.RegRead("HKEY_CLASSES_ROOT\\CLSID\\{"+clsid+"}\\ProgID\\");

        var axo = new ActiveXObject(progid);

        _logger.info("plugin installed.", clsid);

        installedCb && installedCb();
        return true;
    } catch (e) {
        _logger.info("plugin not installed.", clsid);
        notInstalledCb && notInstalledCb();
        return false;
    }
}

module.exports = Plugin = Plugin.extend({
    XVideo: XVideo,

    __init__: function () {
        var self = this;
        _util.forEach(cls, function (clsName, clsFunc) {
            this.clsName = function () {
                var args = {
                    plugin: self,
                    xplugin: self._xobj
                }

                for(var i = 0; i < arguments.length; i++){
                    var cfg = arguments[i] || {};
                    _util.extend(args, cfg)
                }
                return new clsFunc(args);
            }
        });
    },

    _MediaDevices: MediaDevices,
    MediaDevices: function () {
        var self = this;
        return function () {
            return new MediaDevices(self);
        }
    },

    RTCPeerConnection: function (pcConfig, pcConstraints) {
        var self = this;
        return function (pcConfig, pcConstraints) {
            return new RTCPeerConnection(self, pcConfig, pcConstraints);
        }
    },

    attachMediaStream: function (videoTag, stream) {
        var xvideo = new XVideo({width: videoTag.width, height: videoTag.height});
        xvideo.replace(videoTag);

        stream._attachToXVideo = xvideo;
        xvideo._xobj && xvideo._xobj.AttachToWindow(xvideo._xobj.GetRtcWindow(), stream._xobj);
    }
});


Plugin.isPluginInstalled = isPluginInstalled;
Plugin.remove = removePlugin;

Plugin.get = function (id) {
    return id ? plugins[id] : (function () {
        var p;
        _util.forEach(plugins, function (key, val) {
            if(p){
                throw "Plugin load mn";
            }
            p = val;
        })

        return p;
    })();
};

Plugin._load = function (plugin, success, error) {
    _logger.info("load ie plugin.");

    var _p;
    if((_p = Plugin.get(plugin.id)) && _p.state === State.READY){
        throw "Plugin has been load. or loading. " + plugin.id;
    }

    plugins[plugin.id] = plugin;

    plugin.state = State.INJECTING;

    function injected() {
        plugin.state = State.INITIALIZING;

        _util.forEach(xObjCallbacks, function (eventAttr, callback) {
            setXObjCallback(plugin, callback, eventAttr);
        });

        plugin.mediaDevices = new MediaDevices(plugin);

        plugin.state = State.READY;
        _logger.info("ie plugin ", plugin.state);

        success && success(plugin);
    }

    inject(plugin, injected.bind(this));
}

Plugin.load = function (plugin, success, error) {
    _logger.debug("hi while single..");

    if(false && !isPluginInstalled(plugin.classid)){
        _logger.debug("not found ActiveXObject:" + plugin.classid);
        error("error", plugin.state, "Not found ActiveXObject:" + plugin.classid);
        return;
    }
    switch(plugin.state){
        case undefined:
        case State.NONE:
            Plugin._load(plugin, success, error);
            break;
        case State.INJECTING:
        case State.INJECTED:
            error("warn", plugin.state, "Plugin loading. it " + plugin.classid);
            break;
        case State.READY:
            _logger.warn("plugin single success ", plugin.state);
            success(plugin);
            return plugin;
        default:
            _logger.error("Unkown state ", plugin.state);
            error("error", plugin.state, "Unkown state " + plugin.state);
            return;
    }
}

//Plugin.load(plugin);
Plugin.factory = function (cfg) {
    var plugin = new Plugin(cfg || {});
    //Plugin.load(plugin);

    return plugin;
}

Plugin.single = function (success, error, cfg) {
    var t = this;

    var plugin;
    while (!(plugin = Plugin.get())){
        plugin = new Plugin(cfg || {});
        break;
    }
    Plugin.load(plugin, success, error);

    return plugin;
}


function defaultOnError(pcId, BstrError) {
    _logger.info("Plugin", this.id, pcId, BstrError);

    var pc = this.pcs[pcId];

    var error = JSON.parse(BstrError);
    var event = new RTCError(error);

    pc._error(event);
}

var xObjCallbacks = {
    // this is plugin

    onAddstream: function onAddstream(pcId, stream) {
        _logger.info("Plugin", this.id, "onAddstream", pcId, stream);

        var ms = new MediaStream({
            id: pcId + "_s" + stream.id,
            _xobj: stream,
        });

        var pc = this.pcs[pcId];

        pc.remoteStreams = [ms];
        pc.onaddstream && pc.onaddstream({stream: ms});
    },

    onIceCandidate: function onIceCandidate(pcId, BstrIceCandidate) {
        _logger.info("Plugin", this.id, "onIceCandidate", pcId, BstrIceCandidate);

        var pc = this.pcs[pcId];

        var _xcand = JSON.parse(BstrIceCandidate);
        var rtcIceCandidate = new RTCIceCandidate(_xcand);

        pc.onicecandidate && pc.onicecandidate({candidate: rtcIceCandidate});
    },

    //new checking connected completed failed disconnected closed
    onIceConnectionStateChange: function onIceConnectionStateChange(pcId, nowState, oldState) {
        _logger.info("Plugin", this.id, "onIceConnectionStateChange", pcId, nowState, oldState);

        var pc = this.pcs[pcId];
        pc.iceConnectionState = nowState;

        pc.oniceconnectionstatechange && pc.oniceconnectionstatechange({target: {iceConnectionState: nowState}});
    },

    onCreateSessionDescription: function onCreateSessionDescription(pcId, BstrDesc) { //onCreateOfferSuccess
        _logger.info("Plugin", this.id, "onRTCSessionDescriptionCreate", pcId, BstrDesc);

        var pc = this.pcs[pcId];
        var descJSON = JSON.parse(BstrDesc);

        var description = new RTCSessionDescription({
            sdp: descJSON.sdp,
            type: descJSON.type
        });

        switch(descJSON.type){
            case "offer":
                pc._success(description);
                break;
            case "answer":
                pc._success(description);
                break;
            default:
                throw "Unknow sdp type " + descJSON.type;
        }
    },

    onSetLocalDescriptionSuccess: function onSetLocalDescriptionSuccess(pcId) {
        _logger.info("Plugin", this.id, "onSetLocalDescriptionSuccess", pcId);

        var pc = this.pcs[pcId];
        pc._success();
    },

    onSetRemoteDescriptionSuccess: function onSetRemoteDescriptionSuccess(pcId) {
        _logger.info("Plugin", this.id, "onSetRemoteDescriptionSuccess", pcId);

        var pc = this.pcs[pcId];
        pc._success();
    },

    onAddIceCandidateSuccess: function onAddIceCandidateSuccess(pcId) {
        _logger.info("Plugin", this.id, "onAddIceCandidateSuccess", pcId);

        var pc = this.pcs[pcId];
        pc._success();
    },


    onCreateSessionDescriptionError: defaultOnError,
    onSetLocalDescriptionError: defaultOnError,
    onSetRemoteDescriptionError: defaultOnError,
    onAddIceCandidateError: defaultOnError
};
