var _util = require('../../components/Util');
var _logger = _util.tagLogger("IE");

var MediaStream = _util.prototypeExtend({
    //plugin:
    //xplugin:

    //id
    //_xobj: stream,
    //getTracks
    //getVideoTracks
    //getAudioTracks
    //addTrack

    __init__: function () {

    },

    getVideoTracks: function () {
        var self = this;
        var _xtracks = self.xplugin.MediaStreamGetVideoTracks(self._xobj.id);

        var tracks = [];
        _util.forEach(_xtracks, function (index, xtrack) {
            tracks.push(new MediaStreamTrack({
                id: self.id + "_t_" + xtrack.id,
                _xobj: xtrack
            }));
        });
        return tracks;
    },
    getAudioTracks: function () {
        var self = this;
        var _xtracks = self.xplugin.MediaStreamGetAudioTracks(self._xobj.id);

        var tracks = [];
        _util.forEach(_xtracks, function (index, xtrack) {
            tracks.push(new MediaStreamTrack({
                id: self.id + "_t_" + xtrack.id,
                _xobj: xtrack
            }));
        });
        return tracks;
    },

    getTracks: function () {
        var videoTracks = this.getVideoTracks();
        var audioTracks = this.getAudioTracks();

        Array.prototype.push.apply(videoTracks, audioTracks);
    },
    
    addTrack: function () {
        throw "Not support it"
    }
});

module.exports = MediaStream;