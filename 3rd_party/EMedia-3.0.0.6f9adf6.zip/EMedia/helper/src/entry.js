
window.emedia = window.emedia || {};

emedia.helper = emedia.helper || {};

var PCStats = require('../../webrtc/src/components/PCStats');
emedia.helper.PCStats = PCStats;

emedia.helper.pcstats = PCStats.echo;
emedia.helper.intervalPcstats= PCStats.intervalEcho;

emedia.helper.inboundAudio = PCStats.inboundAudio;
emedia.helper.inboundVideo = PCStats.inboundVideo;

emedia.helper.outboundAudio = PCStats.outboundAudio;
emedia.helper.outboundVideo = PCStats.outboundVideo;